import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Portfolio from './components/Portfolio';
import TradeEntry from './components/TradeEntry';
import RollEngine from './components/RollEngine';
import ScenarioSimulator from './components/ScenarioSimulator';
import TradeJournal from './components/TradeJournal';
import Settings from './components/Settings';
import { AppData, Trade, Settings as SettingsType, Portfolio as PortfolioType } from './types';

import { useLivePrice } from './hooks/useLivePrice';

const INITIAL_DATA: AppData = {
  portfolio: {
    symbol: 'HDFC BANK',
    buyPrice: 1650.00,
    quantity: 500,
    effectiveCost: 1650.00,
    totalPremium: 0,
    currentSpot: 1745.20
  },
  trades: [],
  settings: {
    spreadWidth: 50,
    minYield: 0.5,
    rollDays: 5,
    rollDistance: 1.5,
    lotSize: 500,
    priceMode: 'LIVE',
    manualSpotPrice: 1745.20
  }
};

const App: React.FC = () => {
  const [data, setData] = useState<AppData>(() => {
    const saved = localStorage.getItem('heie_data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (!parsed.settings.priceMode) {
          parsed.settings.priceMode = 'LIVE';
          parsed.settings.manualSpotPrice = parsed.portfolio.currentSpot || 1745.20;
        }
        return parsed;
      } catch (e) {
        return INITIAL_DATA;
      }
    }
    return INITIAL_DATA;
  });

  const { price: livePrice } = useLivePrice(data.portfolio.currentSpot);
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    if (data.settings.priceMode === 'LIVE') {
      if (livePrice !== data.portfolio.currentSpot) {
        setData(prev => ({
          ...prev,
          portfolio: {
            ...prev.portfolio,
            currentSpot: livePrice
          }
        }));
      }
    } else {
      if (data.settings.manualSpotPrice !== data.portfolio.currentSpot) {
        setData(prev => ({
          ...prev,
          portfolio: {
            ...prev.portfolio,
            currentSpot: prev.settings.manualSpotPrice
          }
        }));
      }
    }
  }, [livePrice, data.settings.priceMode, data.settings.manualSpotPrice]);

  useEffect(() => {
    localStorage.setItem('heie_data', JSON.stringify(data));
  }, [data]);

  const updatePortfolio = (portfolio: PortfolioType) => {
    setData(prev => ({ ...prev, portfolio }));
  };

  const updateSettings = (settings: SettingsType) => {
    setData(prev => ({ ...prev, settings }));
  };

  const saveTrade = (trade: Trade) => {
    setData(prev => {
      const newTrades = [trade, ...prev.trades];
      const totalPremium = newTrades.reduce((acc, t) => acc + (t.credit * t.quantity), 0);
      const effectiveCost = (prev.portfolio.buyPrice * prev.portfolio.quantity - totalPremium) / prev.portfolio.quantity;
      
      return {
        ...prev,
        trades: newTrades,
        portfolio: {
          ...prev.portfolio,
          totalPremium,
          effectiveCost
        }
      };
    });
    setActiveTab('journal');
  };

  const closeTrade = (id: string) => {
    setData(prev => ({
      ...prev,
      trades: prev.trades.map(t => t.id === id ? { ...t, status: 'CLOSED' } : t)
    }));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard data={data} />;
      case 'portfolio':
        return <Portfolio data={data} onUpdate={updatePortfolio} />;
      case 'trade-entry':
        return <TradeEntry data={data} onSave={saveTrade} />;
      case 'roll-engine':
        return <RollEngine data={data} />;
      case 'simulator':
        return <ScenarioSimulator data={data} />;
      case 'journal':
        return <TradeJournal data={data} onCloseTrade={closeTrade} />;
      case 'settings':
        return <Settings settings={data.settings} onUpdate={updateSettings} />;
      default:
        return <Dashboard data={data} />;
    }
  };

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab} 
      currentSpot={data.portfolio.currentSpot}
      priceMode={data.settings.priceMode}
    >
      {renderContent()}
    </Layout>
  );
};

export default App;
