export interface Portfolio {
  symbol: string;
  buyPrice: number;
  quantity: number;
  effectiveCost: number;
  totalPremium: number;
  currentSpot: number;
}

export interface Trade {
  id: string;
  date: string;
  expiry: string;
  spot: number;
  shortStrike: number;
  shortPremium: number;
  longStrike: number;
  longPremium: number;
  credit: number;
  quantity: number;
  score: number;
  decision: 'ENTRY' | 'ROLL' | 'CLOSE';
  notes?: string;
  status: 'OPEN' | 'CLOSED';
}

export interface Settings {
  spreadWidth: number;
  minYield: number;
  rollDays: number;
  rollDistance: number;
  lotSize: number;
  priceMode: 'LIVE' | 'MANUAL';
  manualSpotPrice: number;
}

export interface AppData {
  portfolio: Portfolio;
  trades: Trade[];
  settings: Settings;
}
