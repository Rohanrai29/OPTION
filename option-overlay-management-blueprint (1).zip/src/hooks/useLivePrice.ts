import { useState, useEffect } from 'react';

const HDFC_SYMBOL = 'HDFCBANK.NS';

export const useLivePrice = (initialPrice: number = 1745.20) => {
  const [price, setPrice] = useState<number>(initialPrice);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPrice = async () => {
    setIsLoading(true);
    try {
      // Attempt to fetch from Yahoo Finance via AllOrigins proxy
      // This is a common workaround for CORS in browser-only apps
      const targetUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${HDFC_SYMBOL}?interval=1m&range=1d`;
      const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(targetUrl)}`;
      
      const response = await fetch(proxyUrl);
      if (!response.ok) throw new Error('Proxy error');
      
      const data = await response.json();
      const parsedData = JSON.parse(data.contents);
      
      const currentPrice = parsedData.chart.result[0].meta.regularMarketPrice;
      
      if (currentPrice) {
        setPrice(currentPrice);
        setLastUpdated(new Date());
        setError(null);
      }
    } catch (err) {
      console.warn('Failed to fetch live price, using simulation:', err);
      // Fallback: Random walk simulation for demo purposes if API fails
      const change = (Math.random() - 0.5) * 2;
      setPrice(prev => Number((prev + change).toFixed(2)));
      setLastUpdated(new Date());
      setError('Live data feed failed. Using simulated price.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPrice();
    const interval = setInterval(fetchPrice, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  return { price, lastUpdated, isLoading, error, refresh: fetchPrice };
};
