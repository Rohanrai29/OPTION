import React from 'react';
import { AppData, Portfolio as PortfolioType } from '../types';
import { Wallet, Pencil, TrendingUp, Shield } from 'lucide-react';

interface PortfolioProps {
  data: AppData;
  onUpdate: (portfolio: PortfolioType) => void;
}

const Portfolio: React.FC<PortfolioProps> = ({ data, onUpdate }) => {
  const [isEditing, setIsEditing] = React.useState(false);
  const [editedPortfolio, setEditedPortfolio] = React.useState(data.portfolio);

  const handleSave = () => {
    onUpdate(editedPortfolio);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
        <div className="flex justify-between items-start mb-8 relative z-10">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-200">
               <Wallet size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-slate-900">{data.portfolio.symbol}</h3>
              <p className="text-slate-500 font-medium">HDFC Bank Limited Equity Portfolio</p>
            </div>
          </div>
          <button 
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <Pencil size={16} />
            <span>{isEditing ? 'Cancel' : 'Adjust Base'}</span>
          </button>
        </div>

        {isEditing ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-in fade-in slide-in-from-top-4 duration-300">
             <div className="space-y-2">
                <label className="text-sm font-medium text-slate-500">Buy Price (₹)</label>
                <input 
                  type="number" 
                  value={editedPortfolio.buyPrice}
                  onChange={(e) => setEditedPortfolio({...editedPortfolio, buyPrice: parseFloat(e.target.value)})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
                />
             </div>
             <div className="space-y-2">
                <label className="text-sm font-medium text-slate-500">Quantity</label>
                <input 
                  type="number" 
                  value={editedPortfolio.quantity}
                  onChange={(e) => setEditedPortfolio({...editedPortfolio, quantity: parseFloat(e.target.value)})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
                />
             </div>
             {data.settings.priceMode === 'MANUAL' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-500">Manual Spot Price (₹)</label>
                  <input 
                    type="number" 
                    value={editedPortfolio.currentSpot}
                    onChange={(e) => setEditedPortfolio({...editedPortfolio, currentSpot: parseFloat(e.target.value)})}
                    className="w-full px-4 py-2 border border-amber-300 bg-amber-50 rounded-lg outline-none focus:ring-2 focus:ring-amber-500" 
                  />
                </div>
             )}
             <div className="flex items-end">
                <button 
                  onClick={handleSave}
                  className="w-full bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700 transition-colors"
                >
                  SAVE CHANGES
                </button>
             </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Buy</p>
              <p className="text-xl font-bold text-slate-800 mt-1">₹{data.portfolio.buyPrice.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Quantity</p>
              <p className="text-xl font-bold text-slate-800 mt-1">{data.portfolio.quantity.toLocaleString()} Shares</p>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Invested</p>
              <p className="text-xl font-bold text-slate-800 mt-1">₹{(data.portfolio.buyPrice * data.portfolio.quantity).toLocaleString()}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Effective Basis</p>
              <p className="text-xl font-bold text-blue-600 mt-1">₹{data.portfolio.effectiveCost.toFixed(2)}</p>
            </div>
          </div>
        )}

        <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none">
           <TrendingUp size={200} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h4 className="flex items-center space-x-2 text-lg font-bold text-slate-800 mb-4">
               <Shield size={20} className="text-green-600" />
               <span>Risk Profile</span>
            </h4>
            <div className="space-y-4">
               <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500">Option Coverage</span>
                  <span className="font-bold text-green-600">100% (Covered)</span>
               </div>
               <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-green-500 h-full w-full"></div>
               </div>
               <p className="text-xs text-slate-400 leading-relaxed">
                  Portfolio is fully covered by equity shares. Any assigned call will be settled against existing holdings, eliminating undefined risk.
               </p>
            </div>
         </div>

         <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h4 className="text-lg font-bold text-slate-800 mb-4">Cost Reduction Tracker</h4>
            <div className="space-y-3">
               <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Premium Collected</span>
                  <span className="font-bold text-blue-600">₹{data.portfolio.totalPremium.toLocaleString()}</span>
               </div>
               <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Yield to Date</span>
                  <span className="font-bold text-blue-600">{((data.portfolio.totalPremium / (data.portfolio.buyPrice * data.portfolio.quantity)) * 100).toFixed(2)}%</span>
               </div>
               <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Cost Reduced By</span>
                  <span className="font-bold text-green-600">₹{(data.portfolio.buyPrice - data.portfolio.effectiveCost).toFixed(2)} / Share</span>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default Portfolio;
