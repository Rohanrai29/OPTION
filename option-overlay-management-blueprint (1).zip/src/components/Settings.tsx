import React from 'react';
import { Settings as SettingsType } from '../types';
import { Save, Info } from 'lucide-react';

interface SettingsProps {
  settings: SettingsType;
  onUpdate: (settings: SettingsType) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdate }) => {
  const [formData, setFormData] = React.useState(settings);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData({
      ...formData,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    });
  };

  const handleSave = () => {
    onUpdate(formData);
    alert('Settings saved successfully.');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-semibold mb-6">Institutional Parameters</h3>
        
        <div className="space-y-6">
          <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 space-y-4">
            <h4 className="text-sm font-bold text-blue-800 uppercase tracking-wider">Spot Price Configuration</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-blue-700">Price Mode</label>
                <select 
                  name="priceMode"
                  value={formData.priceMode}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-blue-200 rounded-lg bg-white text-sm outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="LIVE">Live (Yahoo Finance)</option>
                  <option value="MANUAL">Manual Override</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-blue-700">Manual Price (₹)</label>
                <input 
                  type="number" 
                  name="manualSpotPrice"
                  disabled={formData.priceMode === 'LIVE'}
                  value={formData.manualSpotPrice}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 ${
                    formData.priceMode === 'LIVE' ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-white border-blue-200 text-blue-900'
                  }`}
                />
              </div>
            </div>
            <p className="text-[10px] text-blue-600">
              {formData.priceMode === 'LIVE' 
                ? 'System will use live market data. Manual input is disabled.' 
                : 'System will use the fixed price above for all calculations.'}
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700">Spread Width (₹)</label>
              <Info size={14} className="text-slate-400" />
            </div>
            <input 
              type="number" 
              name="spreadWidth"
              value={formData.spreadWidth}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <p className="text-[11px] text-slate-400">Default distance between short and long strikes.</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700">Minimum Monthly Yield (%)</label>
              <Info size={14} className="text-slate-400" />
            </div>
            <input 
              type="number" 
              name="minYield"
              step="0.1"
              value={formData.minYield}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <p className="text-[11px] text-slate-400">Alert threshold for low premium collection relative to spot.</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Roll Threshold (Days)</label>
              <input 
                type="number" 
                name="rollDays"
                value={formData.rollDays}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
              />
              <p className="text-[11px] text-slate-400">Trigger roll when expiry is within this many days.</p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Roll Distance (%)</label>
              <input 
                type="number" 
                name="rollDistance"
                step="0.1"
                value={formData.rollDistance}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
              />
              <p className="text-[11px] text-slate-400">Trigger roll when spot is within this % of short strike.</p>
            </div>
          </div>

          <div className="pt-4">
            <button 
              onClick={handleSave}
              className="w-full flex items-center justify-center space-x-2 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg active:scale-95"
            >
              <Save size={18} />
              <span>SAVE INSTITUTIONAL SETTINGS</span>
            </button>
          </div>
        </div>
      </div>

      <div className="bg-amber-50 p-6 rounded-xl border border-amber-100">
         <div className="flex items-start space-x-3 text-amber-800">
            <Info size={20} className="shrink-0 mt-0.5" />
            <div className="space-y-1">
               <p className="text-sm font-bold">Data Persistence Notice</p>
               <p className="text-xs leading-relaxed">
                  These settings are stored locally in your browser cache. Clearing your browser data will reset these values to factory defaults.
               </p>
            </div>
         </div>
      </div>
    </div>
  );
};

export default Settings;
