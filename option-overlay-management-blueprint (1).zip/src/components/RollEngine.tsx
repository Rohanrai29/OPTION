import React from 'react';
import { AppData } from '../types';
import { getRollRecommendation } from '../utils/calculations';
import { AlertTriangle, RotateCcw, XCircle, CheckCircle } from 'lucide-react';

interface RollEngineProps {
  data: AppData;
}

const RollEngine: React.FC<RollEngineProps> = ({ data }) => {
  const openTrades = data.trades.filter(t => t.status === 'OPEN');

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-semibold mb-2">Active Positions Monitoring</h3>
        <p className="text-sm text-slate-500 mb-6">Real-time analysis of open spreads against institutional roll rules.</p>

        {openTrades.length === 0 ? (
          <div className="py-12 flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-100 rounded-lg">
             <AlertTriangle size={48} className="mb-4 opacity-20" />
             <p>No active positions found.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {openTrades.map((trade) => {
              const { recommendation, explanation } = getRollRecommendation(trade, data.portfolio.currentSpot, data.settings);
              
              return (
                <div key={trade.id} className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-b border-slate-200">
                    <div>
                      <h4 className="font-bold text-slate-800">HDFC BANK Call Spread</h4>
                      <p className="text-xs text-slate-500">Short: ₹{trade.shortStrike} | Long: ₹{trade.longStrike} | Exp: {trade.expiry}</p>
                    </div>
                    <div className={`px-4 py-1.5 rounded-full text-xs font-bold ${
                      recommendation === 'HOLD' ? 'bg-green-100 text-green-700' :
                      recommendation === 'ROLL' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {recommendation} RECOMMENDED
                    </div>
                  </div>
                  <div className="p-6 flex flex-col md:flex-row gap-8">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${
                           recommendation === 'HOLD' ? 'bg-green-50 text-green-600' :
                           recommendation === 'ROLL' ? 'bg-amber-50 text-amber-600' :
                           'bg-red-50 text-red-600'
                        }`}>
                          {recommendation === 'HOLD' ? <CheckCircle size={20} /> :
                           recommendation === 'ROLL' ? <RotateCcw size={20} /> :
                           <XCircle size={20} />}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-slate-900">{explanation}</p>
                          <p className="text-xs text-slate-500 mt-1">Institutional rule triggered based on spot proximity and theta decay.</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 min-w-[300px]">
                       <div className="p-3 bg-slate-50 rounded-lg">
                          <p className="text-[10px] text-slate-500 font-bold uppercase">Current Spot</p>
                          <p className="text-lg font-mono font-bold">₹{data.portfolio.currentSpot}</p>
                       </div>
                       <div className="p-3 bg-slate-50 rounded-lg">
                          <p className="text-[10px] text-slate-500 font-bold uppercase">Distance to Short</p>
                          <p className={`text-lg font-mono font-bold ${
                            ((trade.shortStrike - data.portfolio.currentSpot) / data.portfolio.currentSpot) < 0.02 ? 'text-red-600' : 'text-slate-700'
                          }`}>
                            {(((trade.shortStrike - data.portfolio.currentSpot) / data.portfolio.currentSpot) * 100).toFixed(2)}%
                          </p>
                       </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="bg-blue-900 text-white p-6 rounded-xl shadow-lg relative overflow-hidden">
         <div className="relative z-10">
           <h3 className="text-lg font-bold mb-2">Institutional Roll Logic</h3>
           <ul className="space-y-2 text-sm text-blue-100">
              <li className="flex items-center space-x-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400"></div>
                <span>Roll if spot is within {data.settings.rollDistance}% of short strike.</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400"></div>
                <span>Roll if {data.settings.rollDays} days or fewer remaining to expiry.</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400"></div>
                <span>Always roll upward/outward to maintain net credit.</span>
              </li>
           </ul>
         </div>
         <RotateCcw className="absolute -right-8 -bottom-8 text-blue-800 h-48 w-48 rotate-12" />
      </div>
    </div>
  );
};

export default RollEngine;
