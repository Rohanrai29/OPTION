import React from 'react';
import { AppData, Trade } from '../types';
import { format } from 'date-fns';
import { Download, Filter, Search } from 'lucide-react';

interface TradeJournalProps {
  data: AppData;
  onCloseTrade: (id: string) => void;
}

const TradeJournal: React.FC<TradeJournalProps> = ({ data, onCloseTrade }) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h3 className="text-lg font-semibold text-slate-800">Historical Trade Logs</h3>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search trades..." 
              className="pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 w-64"
            />
          </div>
          <button className="p-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors">
            <Filter size={18} />
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-semibold hover:bg-slate-900 transition-colors">
            <Download size={16} />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Date</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Type</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Expiry</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Short Strike</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Long Strike</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Credit</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Qty</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Score</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {data.trades.length === 0 ? (
              <tr>
                <td colSpan={9} className="px-6 py-12 text-center text-slate-400">
                  No trade records found.
                </td>
              </tr>
            ) : (
              data.trades.map((trade: Trade) => (
                <tr key={trade.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-slate-700">
                    {format(new Date(trade.date), 'dd MMM yyyy')}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                      trade.decision === 'ENTRY' ? 'bg-blue-100 text-blue-700' :
                      trade.decision === 'ROLL' ? 'bg-amber-100 text-amber-700' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {trade.decision}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {format(new Date(trade.expiry), 'dd MMM yyyy')}
                  </td>
                  <td className="px-6 py-4 text-sm font-mono text-red-600">₹{trade.shortStrike}</td>
                  <td className="px-6 py-4 text-sm font-mono text-green-600">₹{trade.longStrike}</td>
                  <td className="px-6 py-4 text-sm font-mono font-bold text-blue-600">₹{trade.credit.toFixed(2)}</td>
                  <td className="px-6 py-4 text-sm text-slate-600 font-mono">{trade.quantity}</td>
                  <td className="px-6 py-4">
                     <div className={`text-xs font-bold ${
                        trade.score > 70 ? 'text-green-600' : 
                        trade.score > 40 ? 'text-yellow-600' : 
                        'text-red-600'
                     }`}>
                        {trade.score}/100
                     </div>
                  </td>
                  <td className="px-6 py-4">
                     <div className="flex items-center space-x-2">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          trade.status === 'OPEN' ? 'bg-green-100 text-green-800' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {trade.status}
                        </span>
                        {trade.status === 'OPEN' && (
                          <button 
                            onClick={() => onCloseTrade(trade.id)}
                            className="text-[10px] font-bold text-blue-600 hover:underline"
                          >
                            Close
                          </button>
                        )}
                     </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TradeJournal;
