import React from 'react';
import { LayoutDashboard, Wallet, PlusSquare, History, Settings as SettingsIcon, ShieldCheck, LineChart } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentSpot: number;
  priceMode: 'LIVE' | 'MANUAL';
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, currentSpot, priceMode }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'portfolio', label: 'Portfolio', icon: Wallet },
    { id: 'trade-entry', label: 'Trade Entry', icon: PlusSquare },
    { id: 'roll-engine', label: 'Roll Engine', icon: ShieldCheck },
    { id: 'simulator', label: 'Simulator', icon: LineChart },
    { id: 'journal', label: 'Journal', icon: History },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <h1 className="text-xl font-bold tracking-tight text-blue-400">HEIE Blueprint</h1>
          <p className="text-xs text-slate-400 mt-1">Institutional Equity Engine v1.0</p>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                activeTab === item.id ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              <item.icon size={20} />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-800">
          <div className="bg-slate-800 rounded-lg p-3 group relative">
            <div className="flex items-center justify-between mb-1">
              <p className="text-[10px] font-bold text-slate-500 uppercase">HDFC BANK (NSE)</p>
              <div className="flex items-center space-x-1">
                <div className={`h-1.5 w-1.5 rounded-full ${priceMode === 'MANUAL' ? 'bg-amber-500' : 'bg-green-500 animate-pulse'}`}></div>
                <span className="text-[9px] text-slate-400 font-bold">{priceMode === 'MANUAL' ? 'MANUAL' : 'LIVE'}</span>
              </div>
            </div>
            <p className={`text-lg font-mono ${priceMode === 'MANUAL' ? 'text-amber-400' : 'text-green-400'}`}>
              ₹{currentSpot.toLocaleString()}
            </p>
            <button 
              onClick={() => setActiveTab('settings')}
              className="absolute inset-0 bg-slate-800/80 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-lg text-[10px] font-bold text-white uppercase tracking-tighter"
            >
              Change Mode
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-8">
          <h2 className="text-lg font-semibold text-slate-800 capitalize">
            {activeTab.replace('-', ' ')}
          </h2>
          <div className="flex items-center space-x-4">
             <div className="text-right">
                <p className="text-xs text-slate-500">Market Data</p>
                <p className="text-xs font-medium text-slate-400">
                  {priceMode === 'MANUAL' ? 'Manual Override Active' : 'via Yahoo Finance (Proxied)'}
                </p>
             </div>
             <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
                AD
             </div>
          </div>
        </header>
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
