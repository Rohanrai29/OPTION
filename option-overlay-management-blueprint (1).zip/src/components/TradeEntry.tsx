import React, { useState, useEffect } from 'react';
import { Trade, AppData } from '../types';
import { calculateTradeScore, calculateCredit } from '../utils/calculations';
import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

interface TradeEntryProps {
  data: AppData;
  onSave: (trade: Trade) => void;
}

const TradeEntry: React.FC<TradeEntryProps> = ({ data, onSave }) => {
  const [formData, setFormData] = useState<Partial<Trade>>({
    date: new Date().toISOString().split('T')[0],
    expiry: '',
    spot: 1745.20,
    shortStrike: 0,
    shortPremium: 0,
    longStrike: 0,
    longPremium: 0,
    quantity: data.portfolio.quantity,
    status: 'OPEN',
    decision: 'ENTRY'
  });

  const [validation, setValidation] = useState<{ score: number; warnings: string[]; rejects: string[] }>({
    score: 0,
    warnings: [],
    rejects: []
  });

  useEffect(() => {
    const result = calculateTradeScore(formData, data.settings, data.portfolio);
    setValidation(result);
  }, [formData, data.settings, data.portfolio]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name.includes('Strike') || name.includes('Premium') || name.includes('spot') || name.includes('quantity') 
        ? parseFloat(value) || 0 
        : value
    }));
  };

  const credit = calculateCredit(formData.shortPremium || 0, formData.longPremium || 0);
  const spreadWidth = (formData.longStrike || 0) - (formData.shortStrike || 0);
  const maxLoss = (spreadWidth - credit) * (formData.quantity || 0);
  const premiumIncome = credit * (formData.quantity || 0);
  const yieldPct = formData.spot ? (credit / formData.spot) * 100 : 0;

  const handleSave = () => {
    if (validation.rejects.length > 0) return;
    
    const newTrade: Trade = {
      ...formData as Trade,
      id: Math.random().toString(36).substr(2, 9),
      credit,
      score: validation.score
    };
    onSave(newTrade);
    alert('Trade saved to journal.');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold mb-6">Enter Market Data</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Trade Date</label>
              <input 
                type="date" 
                name="date"
                value={formData.date}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Expiry Date</label>
              <input 
                type="date" 
                name="expiry"
                value={formData.expiry}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium text-slate-700">Current Spot (₹)</label>
                <button 
                  onClick={() => setFormData(prev => ({ ...prev, spot: data.portfolio.currentSpot }))}
                  className="text-[10px] font-bold text-blue-600 hover:underline"
                >
                  USE LIVE PRICE
                </button>
              </div>
              <input 
                type="number" 
                name="spot"
                step="0.05"
                value={formData.spot}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Quantity (Shares)</label>
              <input 
                type="number" 
                name="quantity"
                value={formData.quantity}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
              />
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-slate-100">
             <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Spread Legs</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                    <h5 className="text-sm font-bold text-red-700 mb-3">Short Call Strike</h5>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-red-600 font-medium">Strike Price</label>
                        <input type="number" name="shortStrike" value={formData.shortStrike} onChange={handleInputChange} className="w-full px-3 py-1.5 border border-red-200 rounded mt-1 outline-none focus:ring-1 focus:ring-red-400" />
                      </div>
                      <div>
                        <label className="text-xs text-red-600 font-medium">Premium Received</label>
                        <input type="number" name="shortPremium" value={formData.shortPremium} onChange={handleInputChange} className="w-full px-3 py-1.5 border border-red-200 rounded mt-1 outline-none focus:ring-1 focus:ring-red-400" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                    <h5 className="text-sm font-bold text-green-700 mb-3">Long Call Strike</h5>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs text-green-600 font-medium">Strike Price</label>
                        <input type="number" name="longStrike" value={formData.longStrike} onChange={handleInputChange} className="w-full px-3 py-1.5 border border-green-200 rounded mt-1 outline-none focus:ring-1 focus:ring-green-400" />
                      </div>
                      <div>
                        <label className="text-xs text-green-600 font-medium">Premium Paid</label>
                        <input type="number" name="longPremium" value={formData.longPremium} onChange={handleInputChange} className="w-full px-3 py-1.5 border border-green-200 rounded mt-1 outline-none focus:ring-1 focus:ring-green-400" />
                      </div>
                    </div>
                  </div>
                </div>
             </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Calculations & Impact</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-500 font-medium">Net Credit</p>
              <p className="text-lg font-bold text-blue-600">₹{credit.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-500 font-medium">Spread Width</p>
              <p className="text-lg font-bold text-slate-700">₹{spreadWidth.toFixed(2)}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-500 font-medium">Monthly Income</p>
              <p className="text-lg font-bold text-green-600">₹{premiumIncome.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-500 font-medium">Max Loss</p>
              <p className="text-lg font-bold text-red-600">₹{maxLoss.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg col-span-2">
              <p className="text-xs text-slate-500 font-medium">Premium Yield</p>
              <p className="text-lg font-bold text-slate-700">{yieldPct.toFixed(2)}%</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg col-span-2">
              <p className="text-xs text-slate-500 font-medium">New Effective Cost</p>
              <p className="text-lg font-bold text-indigo-600">₹{(((data.portfolio.buyPrice * data.portfolio.quantity) - (data.portfolio.totalPremium + premiumIncome)) / data.portfolio.quantity).toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm sticky top-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold">Rule Engine</h3>
            <div className={`h-12 w-12 rounded-full flex items-center justify-center font-bold text-lg border-4 ${
              validation.score > 70 ? 'border-green-500 text-green-600' : 
              validation.score > 40 ? 'border-yellow-500 text-yellow-600' : 
              'border-red-500 text-red-600'
            }`}>
              {validation.score}
            </div>
          </div>

          <div className="space-y-4 mb-8">
            {validation.rejects.map((err, i) => (
              <div key={i} className="flex items-start space-x-3 p-3 bg-red-50 rounded-lg text-red-700 text-sm">
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <span>{err}</span>
              </div>
            ))}
            {validation.warnings.map((warn, i) => (
              <div key={i} className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg text-yellow-700 text-sm">
                <Info size={18} className="mt-0.5 shrink-0" />
                <span>{warn}</span>
              </div>
            ))}
            {validation.rejects.length === 0 && validation.warnings.length === 0 && (
              <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg text-green-700 text-sm">
                <CheckCircle2 size={18} className="mt-0.5 shrink-0" />
                <span>All institutional rules satisfied. Trade is optimal.</span>
              </div>
            )}
          </div>

          <button 
            disabled={validation.rejects.length > 0}
            onClick={handleSave}
            className={`w-full py-4 rounded-xl font-bold text-white transition-all shadow-lg ${
              validation.rejects.length > 0 
                ? 'bg-slate-300 cursor-not-allowed' 
                : 'bg-blue-600 hover:bg-blue-700 active:scale-95'
            }`}
          >
            EXECUTE ADVISORY ENTRY
          </button>
          <p className="text-[10px] text-slate-400 text-center mt-4">
            * This software is advisory only. Manual entry into broker terminal required.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TradeEntry;
