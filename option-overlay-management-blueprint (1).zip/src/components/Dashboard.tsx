import React from 'react';
import { AppData } from '../types';
import { calculateKPIs } from '../utils/calculations';
import { ArrowUpRight, ArrowDownRight, IndianRupee, Percent, TrendingUp, History } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface DashboardProps {
  data: AppData;
}

const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const kpis = calculateKPIs(data.portfolio, data.trades);

  const stats = [
    { label: 'Total Investment', value: `₹${kpis.investment.toLocaleString()}`, icon: IndianRupee, trend: null },
    { label: 'Current Value (Live)', value: `₹${kpis.currentValue.toLocaleString()}`, icon: TrendingUp, trend: kpis.stockReturn },
    { label: 'Premium Collected', value: `₹${kpis.totalPremium.toLocaleString()}`, icon: History, trend: null },
    { label: 'Effective Cost', value: `₹${kpis.effectiveCost.toFixed(2)}`, icon: IndianRupee, trend: null, sub: `Original: ₹${data.portfolio.buyPrice}` },
    { label: 'Annualized Yield', value: `${kpis.annualizedYield.toFixed(2)}%`, icon: Percent, trend: null },
    { label: 'Win Rate', value: `${kpis.winRate.toFixed(1)}%`, icon: ShieldCheck, trend: null },
  ];

  function ShieldCheck(props: any) {
    return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>;
  }

  // Sample data for charts
  const chartData = [
    { month: 'Jan', premium: 12500, cost: 1650 },
    { month: 'Feb', premium: 14000, cost: 1640 },
    { month: 'Mar', premium: 11000, cost: 1632 },
    { month: 'Apr', premium: 15500, cost: 1620 },
    { month: 'May', premium: 13200, cost: 1612 },
    { month: 'Jun', premium: 14800, cost: 1600 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                <h3 className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</h3>
                {stat.trend !== null && (
                  <p className={`text-xs mt-2 flex items-center ${stat.trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.trend >= 0 ? <ArrowUpRight size={12} className="mr-1" /> : <ArrowDownRight size={12} className="mr-1" />}
                    {Math.abs(stat.trend).toFixed(2)}% vs initial
                  </p>
                )}
                {stat.sub && (
                  <p className="text-xs text-slate-400 mt-2">{stat.sub}</p>
                )}
              </div>
              <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                <stat.icon size={20} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 text-slate-800">Monthly Premium Income</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f1f5f9'}}
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="premium" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 text-slate-800">Effective Cost Basis Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} domain={['auto', 'auto']} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Line type="monotone" dataKey="cost" stroke="#10b981" strokeWidth={3} dot={{r: 4, fill: '#10b981'}} activeDot={{r: 6}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
