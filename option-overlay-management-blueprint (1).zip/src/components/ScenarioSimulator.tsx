import React, { useState } from 'react';
import { AppData } from '../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface ScenarioSimulatorProps {
  data: AppData;
}

const ScenarioSimulator: React.FC<ScenarioSimulatorProps> = ({ data }) => {
  const [hypotheticalSpot, setHypotheticalSpot] = useState(data.portfolio.currentSpot);
  
  const currentTrade = data.trades.find(t => t.status === 'OPEN');
  
  const calculatePL = (spot: number) => {
    const stockPL = (spot - data.portfolio.buyPrice) * data.portfolio.quantity;
    
    let optionPL = 0;
    if (currentTrade) {
      const shortValue = Math.max(0, spot - currentTrade.shortStrike);
      const longValue = Math.max(0, spot - currentTrade.longStrike);
      optionPL = (currentTrade.credit - (shortValue - longValue)) * currentTrade.quantity;
    }
    
    const totalPL = stockPL + optionPL;
    const effectiveCost = ((data.portfolio.buyPrice * data.portfolio.quantity) - (data.portfolio.totalPremium + (currentTrade?.credit || 0) * (currentTrade?.quantity || 0))) / data.portfolio.quantity;
    
    return { stockPL, optionPL, totalPL, effectiveCost };
  };

  const results = calculatePL(hypotheticalSpot);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-semibold mb-6">Scenario Simulator</h3>
        <div className="space-y-4">
          <label className="text-sm font-medium text-slate-700">Hypothetical Spot Price (₹)</label>
          <div className="flex items-center space-x-4">
            <input 
              type="range" 
              min={data.portfolio.buyPrice * 0.7} 
              max={data.portfolio.buyPrice * 1.3} 
              step="1"
              value={hypotheticalSpot}
              onChange={(e) => setHypotheticalSpot(parseFloat(e.target.value))}
              className="flex-1 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <input 
              type="number" 
              value={hypotheticalSpot}
              onChange={(e) => setHypotheticalSpot(parseFloat(e.target.value))}
              className="w-32 px-3 py-2 border border-slate-300 rounded-lg font-mono text-right"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm font-medium text-slate-500 mb-2">Stock P&L</p>
          <div className="flex items-end justify-between">
            <h4 className={`text-2xl font-bold ${results.stockPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ₹{results.stockPL.toLocaleString()}
            </h4>
            <div className={`p-1 rounded ${results.stockPL >= 0 ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
              {results.stockPL >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm font-medium text-slate-500 mb-2">Option Overlay P&L</p>
          <div className="flex items-end justify-between">
            <h4 className={`text-2xl font-bold ${results.optionPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ₹{results.optionPL.toLocaleString()}
            </h4>
            <div className={`p-1 rounded ${results.optionPL >= 0 ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
              {results.optionPL >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm border-b-4 border-b-blue-500">
          <p className="text-sm font-medium text-slate-500 mb-2">Total Combined P&L</p>
          <div className="flex items-end justify-between">
            <h4 className={`text-2xl font-bold ${results.totalPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ₹{results.totalPL.toLocaleString()}
            </h4>
            <div className={`p-1 rounded ${results.totalPL >= 0 ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
              {results.totalPL >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-semibold mb-4 text-slate-800">Visual Impact Projection</h3>
        <div className="relative h-24 bg-slate-50 rounded-lg border border-slate-200 flex items-center px-12">
            <div className="absolute left-0 top-0 h-full w-1 bg-slate-300"></div>
            <div className="flex-1 relative h-1 bg-slate-200">
               {/* Current Spot Marker */}
               <div 
                 className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
                 style={{ left: `${((data.portfolio.currentSpot - data.portfolio.buyPrice * 0.7) / (data.portfolio.buyPrice * 0.6)) * 100}%` }}
               >
                 <div className="w-1 h-6 bg-slate-400"></div>
                 <span className="text-[10px] font-bold text-slate-500 mt-1 uppercase whitespace-nowrap">Current Spot</span>
               </div>
               
               {/* Hypothetical Marker */}
               <div 
                 className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center z-10 transition-all duration-300"
                 style={{ left: `${((hypotheticalSpot - data.portfolio.buyPrice * 0.7) / (data.portfolio.buyPrice * 0.6)) * 100}%` }}
               >
                 <div className="w-3 h-3 rounded-full bg-blue-600 border-2 border-white shadow-lg"></div>
                 <span className="text-[10px] font-bold text-blue-600 mt-1 uppercase whitespace-nowrap">Simulated: ₹{hypotheticalSpot}</span>
               </div>

               {/* Short Strike Marker if exists */}
               {currentTrade && (
                 <div 
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
                    style={{ left: `${((currentTrade.shortStrike - data.portfolio.buyPrice * 0.7) / (data.portfolio.buyPrice * 0.6)) * 100}%` }}
                  >
                    <div className="w-1 h-4 bg-red-400 opacity-50"></div>
                    <span className="text-[10px] font-bold text-red-400 mt-1 uppercase whitespace-nowrap">Short Strike</span>
                  </div>
               )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ScenarioSimulator;
