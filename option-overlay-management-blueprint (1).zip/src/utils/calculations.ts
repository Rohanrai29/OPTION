import { Trade, Settings, Portfolio } from '../types';

export const calculateCredit = (shortPremium: number, longPremium: number): number => {
  return shortPremium - longPremium;
};

export const calculateTradeScore = (trade: Partial<Trade>, settings: Settings, portfolio: Portfolio): { score: number; warnings: string[]; rejects: string[] } => {
  const warnings: string[] = [];
  const rejects: string[] = [];
  let score = 100;

  if (!trade.shortStrike || !trade.longStrike || !trade.shortPremium || !trade.longPremium || !trade.spot) {
    return { score: 0, warnings: [], rejects: ['All trade fields are required'] };
  }

  // Reject Rules
  if (trade.longStrike <= trade.shortStrike) {
    rejects.push('Long strike must be higher than short strike for a credit spread.');
    score = 0;
  }
  
  const credit = trade.shortPremium - trade.longPremium;
  if (credit <= 0) {
    rejects.push('Net credit must be positive.');
    score = 0;
  }

  if (trade.quantity && trade.quantity > portfolio.quantity) {
    rejects.push('Quantity exceeds covered shares in portfolio.');
    score = 0;
  }

  // Warning Rules
  if (trade.shortStrike <= trade.spot) {
    warnings.push('Short strike is ATM or ITM. High risk of assignment.');
    score -= 20;
  }

  const yieldPct = (credit / trade.spot) * 100;
  if (yieldPct < settings.minYield) {
    warnings.push(`Yield (${yieldPct.toFixed(2)}%) is below minimum threshold (${settings.minYield}%).`);
    score -= 15;
  }

  // Adjust score based on distance from spot
  const otmDistance = ((trade.shortStrike - trade.spot) / trade.spot) * 100;
  if (otmDistance < 2) {
    warnings.push('Short strike is very close to spot price (< 2%).');
    score -= 10;
  }

  return { 
    score: Math.max(0, score), 
    warnings, 
    rejects 
  };
};

export const calculateKPIs = (portfolio: Portfolio, trades: Trade[]) => {
  const totalPremium = trades.reduce((acc, t) => acc + (t.credit * t.quantity), 0);
  const investment = portfolio.buyPrice * portfolio.quantity;
  const currentValue = portfolio.currentSpot * portfolio.quantity;
  const stockReturn = ((currentValue - investment) / investment) * 100;
  const effectiveCost = (investment - totalPremium) / portfolio.quantity;
  const annualizedYield = (totalPremium / investment) * 12 * 100; // Simplified monthly to annual
  const rollCount = trades.filter(t => t.decision === 'ROLL').length;
  const winRate = trades.length > 0 ? (trades.filter(t => t.status === 'CLOSED').length / trades.length) * 100 : 0;

  return {
    investment,
    currentValue,
    stockReturn,
    totalPremium,
    effectiveCost,
    annualizedYield,
    rollCount,
    winRate
  };
};

export const getRollRecommendation = (trade: Trade, currentSpot: number, settings: Settings): { recommendation: 'HOLD' | 'ROLL' | 'CLOSE'; explanation: string } => {
  const daysToExpiry = (new Date(trade.expiry).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
  const distanceToShort = ((trade.shortStrike - currentSpot) / currentSpot) * 100;

  if (distanceToShort <= settings.rollDistance) {
    return { recommendation: 'ROLL', explanation: `Spot price is within ${settings.rollDistance}% of short strike.` };
  }

  if (daysToExpiry <= settings.rollDays) {
    return { recommendation: 'ROLL', explanation: `Expiry is approaching (${Math.round(daysToExpiry)} days remaining).` };
  }

  if (currentSpot > trade.longStrike) {
     return { recommendation: 'CLOSE', explanation: 'Spot price has exceeded long strike. Max loss reached.' };
  }

  return { recommendation: 'HOLD', explanation: 'Current position is within safe parameters.' };
};
